#ifndef NSE_FS
#define NSE_FS

#define LFSLIBNAME "lfs"
LUALIB_API int luaopen_lfs (lua_State *L);

#endif
